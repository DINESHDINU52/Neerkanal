import { Injectable } from '@nestjs/common';
@Injectable() export class MailService { async send(to:string,subject:string,html:string){ console.log(`MAIL placeholder -> ${to}: ${subject}`); return {queued:false,provider:'not-configured'}; } }
