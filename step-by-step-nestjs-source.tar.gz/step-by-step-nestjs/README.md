# Step-by-Step Platform — NestJS API

Backend foundation based on the supplied Step-by-Step requirements and Nerkanal HR wireframe guide.

## Roles
- CANDIDATE: registration, profile, video assessment record, job discovery, applications, interview/offer tracking, mock interview.
- RECRUITER: manpower requests, job posting, candidate search, screening, interviews, feedback, offers.
- HR: onboarding, employee directory, attendance, leave, payroll, performance, engagement, learning, complaints, exit, policies, reports, administration.
- ADMIN/SUPER_ADMIN: platform/company configuration.

## Run
1. Copy `.env.example` to `.env`.
2. `docker compose up -d postgres`
3. `npm install`
4. `npx prisma generate`
5. `npx prisma migrate dev --name init`
6. `npm run seed`
7. `npm run start:dev`
8. Swagger: `http://localhost:3000/docs`

The API intentionally isolates external services (mail, AI video scoring, job-source ingestion, maps, meetings, statutory-rule providers) behind service methods so production providers can be added without changing business workflows.
