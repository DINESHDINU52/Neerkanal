import { Module } from '@nestjs/common';
import { JobSourceService } from './job-source.service';
import { VideoAssessmentService } from './video-assessment.service';
import { MailService } from './mail.service';
@Module({ providers:[JobSourceService,VideoAssessmentService,MailService], exports:[JobSourceService,VideoAssessmentService,MailService] }) export class IntegrationsModule {}
