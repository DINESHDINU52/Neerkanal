import { Injectable } from '@nestjs/common';
export interface ExternalJob { externalId:string; title:string; company:string; city?:string; applyUrl:string; source:string; skills:string[]; salaryMin?:number; salaryMax?:number; }
@Injectable() export class JobSourceService {
  async fetchFromConfiguredSources():Promise<ExternalJob[]> { return []; }
  async normalizeAndDeduplicate(jobs:ExternalJob[]){ const seen=new Set<string>(); return jobs.filter(j=>{const k=`${j.source}:${j.externalId}`;if(seen.has(k))return false;seen.add(k);return true;}); }
}
