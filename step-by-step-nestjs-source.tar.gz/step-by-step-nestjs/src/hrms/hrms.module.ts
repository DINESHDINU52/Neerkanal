import{Module}from'@nestjs/common';import{HrmsController}from'./hrms.controller';@Module({controllers:[HrmsController]})export class HrmsModule{}
