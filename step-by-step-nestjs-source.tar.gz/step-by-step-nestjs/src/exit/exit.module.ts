import{Module}from'@nestjs/common';import{ExitController}from'./exit.controller';@Module({controllers:[ExitController]})export class ExitModule{}
