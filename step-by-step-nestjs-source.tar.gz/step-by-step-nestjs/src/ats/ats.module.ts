import{Module}from'@nestjs/common';import{AtsController}from'./ats.controller';@Module({controllers:[AtsController]})export class AtsModule{}
