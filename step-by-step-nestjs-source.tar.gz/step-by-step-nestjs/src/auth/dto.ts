import { IsEmail, IsEnum, IsOptional, IsString, MinLength } from 'class-validator';
export enum Role { CANDIDATE='CANDIDATE', RECRUITER='RECRUITER', HR='HR', ADMIN='ADMIN', SUPER_ADMIN='SUPER_ADMIN' }
export class RegisterDto { @IsEmail() email!:string; @IsString() @MinLength(8) password!:string; @IsString() name!:string; @IsOptional() @IsString() phone?:string; }
export class LoginDto { @IsEmail() email!:string; @IsString() password!:string; @IsOptional() @IsEnum(Role) role?:Role; }
export class VerifyDto { @IsEmail() email!:string; @IsString() code!:string; }
