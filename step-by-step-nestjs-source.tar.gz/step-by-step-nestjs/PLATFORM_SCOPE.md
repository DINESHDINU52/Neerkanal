# Requirement → implementation map

## Candidate Portal
- Email registration + verification: `src/auth`
- Profile + 60% application gate: `src/candidates`, `src/applications`
- Five video attempts / 90-day score window: `src/candidates`
- Job search by role/skill/city; internal jobs ranked first: `src/jobs`
- Application tracker: `src/applications`
- Interview + feedback + offers: `src/interviews`, `src/offers`

## Recruiter ATS
- Manpower request → approval → recruiter assignment: `src/ats`
- Job posting: `src/jobs`
- Candidate/application pool and screening: `src/ats`
- Interview scheduling and panel feedback: `src/interviews`
- Offer release and acceptance: `src/offers`

## HRMS
- Onboarding and employee conversion: `src/hrms`
- Attendance, leave, payroll, performance, engagement, learning, complaints, exit, policies, reports, administration: corresponding module directories under `src/`
- Notifications: `src/notifications`
- Jarvis command API: `src/jarvis`

## Production integration points
1. AI face/communication/confidence/passion assessment needs a dedicated video/ML provider and consent/privacy controls.
2. LinkedIn and other job-source ingestion must use each source's permitted API/licensing; scraping is deliberately not hard-coded.
3. Video meeting requires WebRTC/SFU infrastructure or a permitted meeting provider.
4. Google Maps/location services require a provider key and mobile permissions.
5. Biometric/door/CCTV attendance requires device-specific adapters.
6. Labour-law, PT/PF/ESI/LWF/minimum-wage rules need a maintained jurisdiction ruleset and legal review; the API should not invent statutory values.
7. Email/SMS/WhatsApp need configured providers.
8. File storage needs S3-compatible storage in production.

## Security requirements before production
- Replace demo secrets.
- Add refresh-token rotation, rate limiting, audit logging, CSRF strategy for cookie auth if used, encryption-at-rest policy, secrets manager, object-storage signed URLs, consent records, retention/deletion policies, and tenant isolation.
- Add automated tests, migrations, observability, backups, and disaster recovery.
